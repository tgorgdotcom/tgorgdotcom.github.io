// Jacob Klint, 7/27/2006

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.DirectX.DirectSound;
using System.Threading;
using System.Collections.Specialized;

namespace User.DirectX.DirectSound
{
	public class VolumeMeter : System.Windows.Forms.UserControl
	{
		public delegate void VolumeChangedEventHandler(VolumeChangedEventArgs vcea);
		public event VolumeChangedEventHandler VolumeChanged;

		private const int SAMPLES = 110;
        private const int SAMPLE_RATE = 11025;
		private static int[] SAMPLE_FORMAT_ARRAY = {SAMPLES, 2, 1};
		private static CaptureDevicesCollection audioDevices;
		private static StringCollection deviceNames;

		private string deviceName = "(none)";
		private int deviceIndex = -1;
		private Microsoft.DirectX.DirectSound.CaptureBuffer buffer;
		private System.Threading.Thread liveVolumeThread;
		private int sampleDelay = 100;
		private int frameDelay = 10;
		private bool autoStart = true;
		private User.Windows.Forms.ProgressBarGradient progressBar1;
		private User.Windows.Forms.ProgressBarGradient progressBar2;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		static VolumeMeter()
		{
			// populate the audio device list
			audioDevices = new CaptureDevicesCollection();
			deviceNames = new StringCollection();

			for(int i = 0; i < audioDevices.Count; i++)
			{
				deviceNames.Add(audioDevices[i].Description);
			}		
		}


		public VolumeMeter() 
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			progressBar1.MaximumValue = Int16.MaxValue + 1;
			progressBar2.MaximumValue = progressBar1.MaximumValue;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if( components != null )
					components.Dispose();
			}			
			
			Stop();

			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.progressBar1 = new User.Windows.Forms.ProgressBarGradient();
			this.progressBar2 = new User.Windows.Forms.ProgressBarGradient();
			this.SuspendLayout();
			// 
			// progressBar1
			// 
			this.progressBar1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.progressBar1.Dock = System.Windows.Forms.DockStyle.Top;
			this.progressBar1.Location = new System.Drawing.Point(8, 8);
			this.progressBar1.MaximumColor = System.Drawing.Color.Crimson;
			this.progressBar1.MaximumValue = 128;
			this.progressBar1.MidColor = System.Drawing.Color.Gold;
			this.progressBar1.MidColorPosition = 0.4F;
			this.progressBar1.MinimumColor = System.Drawing.Color.Lime;
			this.progressBar1.MinimumValue = 0;
			this.progressBar1.MouseInteractive = false;
			this.progressBar1.Name = "progressBar1";
			this.progressBar1.Orientation = System.Windows.Forms.Orientation.Horizontal;
			this.progressBar1.ShowMidColor = true;
			this.progressBar1.Size = new System.Drawing.Size(160, 20);
			this.progressBar1.TabIndex = 0;
			this.progressBar1.Value = 128;
			// 
			// progressBar2
			// 
			this.progressBar2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.progressBar2.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.progressBar2.Location = new System.Drawing.Point(8, 36);
			this.progressBar2.MaximumColor = System.Drawing.Color.Crimson;
			this.progressBar2.MaximumValue = 128;
			this.progressBar2.MidColor = System.Drawing.Color.Gold;
			this.progressBar2.MidColorPosition = 0.4F;
			this.progressBar2.MinimumColor = System.Drawing.Color.Lime;
			this.progressBar2.MinimumValue = 0;
			this.progressBar2.MouseInteractive = false;
			this.progressBar2.Name = "progressBar2";
			this.progressBar2.Orientation = System.Windows.Forms.Orientation.Horizontal;
			this.progressBar2.ShowMidColor = true;
			this.progressBar2.Size = new System.Drawing.Size(160, 20);
			this.progressBar2.TabIndex = 1;
			this.progressBar2.Value = 128;
			// 
			// VolumeMeter
			// 
			this.Controls.Add(this.progressBar2);
			this.Controls.Add(this.progressBar1);
			this.DockPadding.All = 8;
			this.Name = "VolumeMeter";
			this.Size = new System.Drawing.Size(176, 64);
			this.ResumeLayout(false);

		}
		#endregion

		protected override void OnResize(EventArgs e)
		{
			if(progressBar1.Orientation == Orientation.Horizontal)
			{
				SuspendLayout();
				progressBar1.Dock = DockStyle.Top;
				progressBar1.Height = ClientRectangle.Height / 2 - 8 - 2;

				progressBar2.Dock = DockStyle.Bottom;
				progressBar2.Height = progressBar1.Height;

				progressBar1.Width = ClientRectangle.Width - 16;
				progressBar2.Width = progressBar1.Width;
				progressBar2.Left = progressBar1.Left;
				ResumeLayout(true);
			}
			else
			{
				SuspendLayout();
				progressBar1.Dock = DockStyle.Left;
				progressBar1.Width = ClientRectangle.Width / 2 - 8 - 2;

				progressBar2.Dock = DockStyle.Right;
				progressBar2.Width = progressBar1.Width;

                progressBar1.Height = ClientRectangle.Height;
				progressBar2.Height = progressBar1.Height;
				ResumeLayout(true);
			}
		}

		public bool AutoStart
		{
			get
			{
				return autoStart;
			}
			set
			{
				autoStart = value;
			}
		}

		public IList DeviceNames
		{
			get
			{
				return deviceNames;
			}
		}

		public int SelectedDeviceIndex
		{
			get
			{
				return deviceNames.IndexOf(deviceName);
			}

			set
			{
				if(deviceIndex != value)
				{
					Stop();

					if((value >= 0) && (value < deviceNames.Count))
					{

						deviceIndex = value;
						deviceName = deviceNames[deviceIndex];	
					
						if(autoStart)
						{					
							Start();
						}
					}
					else
					{
						deviceIndex = -1;
						deviceName = "(none)";
					}			
				}
			}
		}

		public bool VisualizerOn
		{
			get
			{
				return (liveVolumeThread != null);
			}

			set
			{
				if(VisualizerOn != value)
				{
					if(value)
					{
						Start();
					}
					else
					{
						Stop();
					}
				}
			}
		}

		public void Start()
		{
			Stop();

			if(deviceIndex != -1)
			{
				// initialize the capture buffer and start the animation thread
				Capture cap = new Capture(audioDevices[deviceIndex].DriverGuid);
				CaptureBufferDescription desc = new CaptureBufferDescription();
				WaveFormat wf = new WaveFormat();
				wf.BitsPerSample = 16;
                wf.SamplesPerSecond = SAMPLE_RATE;
				wf.Channels = 2;
				wf.BlockAlign = (short)(wf.Channels * wf.BitsPerSample / 8);
				wf.AverageBytesPerSecond = wf.BlockAlign * wf.SamplesPerSecond;
				wf.FormatTag = WaveFormatTag.Pcm;

				desc.Format = wf;
				desc.BufferBytes = SAMPLES * wf.BlockAlign;
					
				buffer = new Microsoft.DirectX.DirectSound.CaptureBuffer(desc, cap);
				buffer.Start(true);

				liveVolumeThread = new Thread(new ThreadStart(updateProgress));	
				liveVolumeThread.Priority = ThreadPriority.Lowest;
				liveVolumeThread.Start();
            }
		}

		public void Stop()
		{
			if(liveVolumeThread != null)
			{
				liveVolumeThread.Abort();
				liveVolumeThread.Join();
				liveVolumeThread = null;
			}
		
			if(buffer != null)
			{
				if(buffer.Capturing)
				{
					buffer.Stop();
				}

				buffer.Dispose();
				buffer = null;
			}			
		}

		public int SampleDelay
		{
			get
			{
				return sampleDelay;
			}

			set
			{
				sampleDelay = Math.Max(0, value);

				if(frameDelay > sampleDelay)
				{
					frameDelay = sampleDelay;
				}
			}
		}

		public int FrameDelay
		{
			get
			{
				return frameDelay;
			}

			set
			{
				frameDelay = Math.Max(0, Math.Min(sampleDelay, value));
			}
		}

		public BorderStyle BorderStyle
		{
			get
			{
				return progressBar1.BorderStyle;
			}

			set
			{
				progressBar1.BorderStyle = value;
				progressBar2.BorderStyle = value;
			}
		}

		public string SelectedDeviceName
		{
			get
			{
				return deviceName;
			}
			
			set
			{
				SelectedDeviceIndex = deviceNames.IndexOf(value);
			}
		}

		public Orientation Orientation
		{
			get
			{
				return progressBar1.Orientation;
			}
			
			set
			{
				SuspendLayout();
				progressBar1.Orientation = value;
				progressBar2.Orientation = value;
				ResumeLayout();

				OnResize(null);
			}
		}

		private void updateProgress()
		{
			while(true)
			{
				int tempFrameDelay = frameDelay;
				int tempSampleDelay = sampleDelay;
                int bufferWritePos = 0;
                int bufferReadPos = 0;
                buffer.GetCurrentPosition(out bufferWritePos, out bufferReadPos);
				Array samples = buffer.Read(0, typeof(Int16), LockFlag.FromWriteCursor, SAMPLE_FORMAT_ARRAY);

				// for each channel, determine the step size necessary for each iteration
				int leftGoal = 0;
                int rightGoal = 0;
				
				// average across all samples to get the goals
				for(int i = 0; i < SAMPLES; i++)
				{
                    int testValue = (Int16)samples.GetValue(i, 0, 0);
                    int testValue2 = (Int16)samples.GetValue(i, 1, 0);

                    if (Math.Abs(testValue) > leftGoal)
                    { leftGoal = Math.Abs(testValue); }

                    else if (Math.Abs(testValue2) > rightGoal)
                    { rightGoal = Math.Abs(testValue2); }
				}

                float rangeLeft = leftGoal - progressBar1.Value;
                float rangeRight = rightGoal - progressBar2.Value;

                float initialValueLeft = progressBar1.Value;
                float initialValueRight = progressBar2.Value;

                float stepSizeLeft = rangeLeft / (tempSampleDelay / tempFrameDelay);
                double absStepSizeLeft = stepSizeLeft;          //have convert to avoid a error
                absStepSizeLeft = Math.Abs(absStepSizeLeft);    //when abs()'ing the lowest value
                if (absStepSizeLeft < .01)
                {
                    stepSizeLeft = Math.Sign(rangeLeft) * (float).01;
                }

                float stepSizeRight = rangeRight / (tempSampleDelay / tempFrameDelay);
                double absStepSizeRight = stepSizeRight;        //have convert to avoid a error
                absStepSizeRight = Math.Abs(absStepSizeRight);    //when abs()'ing the lowest value
                if (absStepSizeRight < .01)
                {
                    stepSizeRight = Math.Sign(rangeRight) * (float).01;
                }
                double absStepSize2 = Math.Abs(stepSizeRight);


				// increment/decrement the bars' values until both equal their desired goals,
				// sleeping between iterations
				if((progressBar1.Value == leftGoal) && (progressBar2.Value == rightGoal))
				{
					Thread.Sleep(tempSampleDelay);
				}
				else
				{
					if(VolumeChanged != null)
					{
						VolumeChanged(new VolumeChangedEventArgs(progressBar1.Value, progressBar2.Value, leftGoal, rightGoal));
					}

					do
					{
                        try
                        {
                            if (progressBar1.Value != leftGoal)
                            {
                                // if the distance between the final position and the current position is less than
                                // the step, then just assign the final position value to the progressbar
                                if (absStepSizeLeft < Math.Abs(leftGoal - progressBar1.Value))
                                {
                                    initialValueLeft += stepSizeLeft;
                                    progressBar1.Value = (int)Math.Round(initialValueLeft);
                                }
                                else
                                {
                                    progressBar1.Value = leftGoal;
                                }
                            }

                            if (progressBar2.Value != rightGoal)
                            {
                                // if the distance between the final position and the current position is less than
                                // the step, then just assign the final position value to the progressbar
                                if (absStepSize2 < Math.Abs(rightGoal - progressBar2.Value))
                                {
                                    initialValueRight += stepSizeRight;
                                    progressBar2.Value = (int)Math.Round(initialValueRight);
                                }
                                else
                                {
                                    progressBar2.Value = rightGoal;
                                }
                            }
                        }

                        catch (SystemException e)
                        {
                            MessageBox.Show("Exemption: " + e.Message);
                        }

						Thread.Sleep(tempFrameDelay);
					} while((progressBar1.Value != leftGoal) || (progressBar2.Value != rightGoal));
				}
			}
		}
	}

	public class VolumeChangedEventArgs : EventArgs
	{
		private int oldLeft;
		private int oldRight;
		private int newLeft;
		private int newRight;

		public VolumeChangedEventArgs(int oldLeft, int oldRight, int newLeft, int newRight)
		{
			this.oldLeft = oldLeft;
			this.oldRight = oldRight;
			this.newLeft = newLeft;
			this.newRight = newRight;
		}

		public int OldLeft
		{
			get
			{
				return oldLeft;
			}
		}

		public int OldRight
		{
			get
			{
				return oldRight;
			}
		}

		public int NewLeft
		{
			get
			{
				return newLeft;
			}
		}

		public int NewRight
		{
			get
			{
				return newRight;
			}
		}

		public int DeltaLeft
		{
			get
			{
				return (newLeft - oldLeft);
			}
		}

		public int DeltaRight
		{
			get
			{
				return (newRight - oldRight);
			}
		}
	}
}
