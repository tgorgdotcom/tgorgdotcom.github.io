<?php 
	$where = $_GET["where"]; 
?>

<html>
	<head>
		<title>Logging you in...</title>
	
			<script type="text/javascript" language="javascript">
			function logMeIn() {
				var frameDocument = document.getElementById("getLogin").contentWindow.document;
				
				// Older Netscape browsers (v.6) won't get the document object through contentWindow
				if (frameDocument == null)
				{
					frameDocument = document.getElementById("getLogin").contentDocument;
				}
				
				<?php
					if ($where == "dotproject") {

						$username = $_SERVER["PHP_AUTH_USER"];
						
						// if we're already logged in, get out of this and reload the page in the top
						echo "if (frameDocument.loginform != null) {\n";
						// when we're logged in automaticially, we'll kick out of the frame
						echo "frameDocument.loginform.target = \"_top\";\n";
						echo "frameDocument.loginform.username.value = \"".$username."\";\n";
						echo "frameDocument.loginform.password.value = \"".$_SERVER["PHP_AUTH_PW"]."\";\n";
						
						// we need to send the submit button's values, so we'll simulate a 
						// click instead of doing form.submit();
						
						// Also, there are two elements named login (the second one is the appropriate button),
						// so we'll get the second one and simulate a click
						echo "var loginElements = frameDocument.getElementsByName(\"login\");\n";
						echo "loginElements[1].click();\n";
						echo "}\n";
						echo "else {\n";
						echo "location.href = \"dotproject/\";";
						echo "}\n";
					}

					else if ($where == "inventory")	{
						// if we're already logged in, get out of this and reload the page in the top
						echo "if (frameDocument.forms[0]!= null) {\n";
						// inventory module only likes users with a username of 6 to 8 characters; 
						// they will have to be cut short when the admin creates the users
						echo "frameDocument.forms[0].logon.value = \"".substr($_SERVER["PHP_AUTH_USER"], 0 , 8)."\";\n";
						echo "frameDocument.forms[0].pass.value = \"".$_SERVER["PHP_AUTH_PW"]."\";\n";
						
						// simulate a click for the click button, since for some reason forms[0].submit(); doesn't work...
						echo "frameDocument.forms[0].submit.click()\n";
						echo "}\n";
						echo "else {\n";
						echo "location.href = \"inventory/\";";
						echo "}\n";
					}
				?>
			}
			</script>		
	</head>
	<body>
		<div align="center">Please Wait...</div>
		<br/><br/>
		<div align="center">
			<?php

				if ($where == "dotproject") {
					echo "<iframe src=\"dotproject/index.php\" height=\"0\" width=\"0\" id=\"getLogin\" onload=\"logMeIn()\"></iframe>";
				}

				else if ($where == "inventory")	{
					echo "<iframe src=\"inventory/login.php\" height=\"0\" width=\"0\" id=\"getLogin\" onload=\"logMeIn()\"></iframe>";
				}
			?>
		</div>
	</body>
</html>